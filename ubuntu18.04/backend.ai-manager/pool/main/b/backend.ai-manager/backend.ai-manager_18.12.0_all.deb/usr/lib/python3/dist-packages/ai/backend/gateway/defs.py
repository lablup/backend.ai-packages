# Redis database IDs depending on purposes

REDIS_STAT_DB = 0
REDIS_RLIM_DB = 1
REDIS_LIVE_DB = 2
REDIS_IMAGE_DB = 3
