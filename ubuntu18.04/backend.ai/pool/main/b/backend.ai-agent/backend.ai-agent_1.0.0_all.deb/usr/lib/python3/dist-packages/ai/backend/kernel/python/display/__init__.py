'''
This module is an equivalent of IPython.display module.
'''

from ai.backend.helpers.display import display

__all__ = (
    'display',
)
