class InitializationError(Exception):
    pass


class InsufficientResource(Exception):
    pass
