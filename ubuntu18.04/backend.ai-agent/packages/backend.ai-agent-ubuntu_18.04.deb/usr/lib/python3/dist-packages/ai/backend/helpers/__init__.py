'''
A helper package for user-written Python codes.
'''

from .package import install

__all__ = (
    'install',
)
